package api

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"time"

	log "github.com/sirupsen/logrus"
)

const (
	LAMBDA_AGENT_NAME_HEADER_KEY       = "Lambda-Extension-Name"
	LAMBDA_AGENT_IDENTIFIER_HEADER_KEY = "Lambda-Extension-Identifier"
)

type LambdaExtensionApiClient struct {
	runTimeAPIURL    string
	agentName        string
	registrationBody string
}

func NewLambdaExtensionApiClient(agentName string, registrationBody string) *LambdaExtensionApiClient {
	apiAddress := os.Getenv("AWS_LAMBDA_RUNTIME_API")
	return &LambdaExtensionApiClient{
		runTimeAPIURL:    fmt.Sprintf("http://%v/2020-01-01/extension", apiAddress),
		agentName:        agentName,
		registrationBody: registrationBody,
	}
}

func (lambdaExtensionApiClient *LambdaExtensionApiClient) Register() string {
	log.WithFields(log.Fields{"apiAddress": lambdaExtensionApiClient.runTimeAPIURL}).Info("Registering to RuntimeAPIClient on ")

	requestBody, error := json.Marshal(lambdaExtensionApiClient.registrationBody)
	if error != nil {
		log.Fatalln(error)
	}

	request, error := http.NewRequest("POST", lambdaExtensionApiClient.runTimeAPIURL+"/register", bytes.NewBuffer(requestBody))
	request.Header.Set("Content-Type", "application/json")
	request.Header.Set(LAMBDA_AGENT_NAME_HEADER_KEY, lambdaExtensionApiClient.agentName)
	if error != nil {
		log.Fatalln(error)
	}

	timeout := time.Duration(5 * time.Second)
	client := http.Client{Timeout: timeout}

	response, error := client.Do(request)
	if error != nil {
		log.Fatalln(error)
	}

	agentIdentifier := response.Header.Get(LAMBDA_AGENT_IDENTIFIER_HEADER_KEY)
	defer response.Body.Close()
	return agentIdentifier
}

func (lambdaExtensionApiClient *LambdaExtensionApiClient) Next(agentIdentifier string) string {
	request, error := http.NewRequest("GET", lambdaExtensionApiClient.runTimeAPIURL+"/event/next", nil)
	request.Header.Set("Content-Type", "application/json")
	request.Header.Set(LAMBDA_AGENT_IDENTIFIER_HEADER_KEY, agentIdentifier)
	if error != nil {
		log.Fatalln(error)
	}

	timeout := time.Duration(5 * time.Second)
	client := http.Client{Timeout: timeout}

	response, error := client.Do(request)
	if error != nil {
		log.Fatalln(error)
	}
	defer response.Body.Close()
	body, error := ioutil.ReadAll(response.Body)
	if error != nil {
		log.Fatalln(error)
	}
	log.WithFields(log.Fields{"data": string(body)}).Info("Received response from RuntimeAPIClient: ")
	return string(body)
}
