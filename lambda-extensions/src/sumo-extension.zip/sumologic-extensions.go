package main

import (
	"fmt"
	"os"
	"path/filepath"

	"api"

	log "github.com/sirupsen/logrus"
)

const (
	timeoutMs = 1000
	maxBytes  = 262144
	maxLen    = 10000

	receiverIP   = "0.0.0.0"
	receiverPort = 4243
)

//"SumoLogicExtension"
type SumoLogicExtension struct {
	agentName          string
	registrationBody   string
	subscriptionBody   string
	extensionApiClient *api.LambdaExtensionApiClient
	agentId            string
}

func NewSumoLogicExtension(agentName, registrationBody, subscriptionBody string) *SumoLogicExtension {
	return &SumoLogicExtension{
		agentName:        agentName,
		registrationBody: registrationBody,
		subscriptionBody: subscriptionBody,
	}
}

func (sumoLogicExtension *SumoLogicExtension) SetUp() {
	log.WithFields(log.Fields{"agentName": sumoLogicExtension.agentName}).Info("Intializing Sumo Logic Extension with ")
	sumoLogicExtension.extensionApiClient = api.NewLambdaExtensionApiClient(sumoLogicExtension.agentName, sumoLogicExtension.registrationBody)
	// Register early so Runtime could start in parallel
	sumoLogicExtension.agentId = sumoLogicExtension.extensionApiClient.Register()
}

func (sumoLogicExtension *SumoLogicExtension) RunForever() {
	log.WithFields(log.Fields{"agentName": sumoLogicExtension.agentName}).Info("Serving Sumo Logic Extension with ")
	for {
		response := sumoLogicExtension.extensionApiClient.Next(sumoLogicExtension.agentId)
		log.Info(response)
	}

}

func main() {
	registrationBody := `{"events": ["INVOKE"]}`

	subscriptionBody := fmt.Sprintf(`{
        "destination": {
            "protocol": "HTTP",
            "URI": "http://sandbox:%v"
        },
        "types": ["platform", "function"],
        "buffering": {
            "timeoutMs": %v,
            "max_bytes": %v,
            "max_len": %v
        }
    }`, receiverPort, timeoutMs, maxBytes, maxLen)

	log.WithFields(log.Fields{"registrationBody": registrationBody, "subscriptionBody": subscriptionBody}).Info("Starting Sumo Logic Extension ")
	sumoLogicExtension := NewSumoLogicExtension(filepath.Base(os.Args[0]), registrationBody, subscriptionBody)
	sumoLogicExtension.SetUp()
	sumoLogicExtension.RunForever()
}
